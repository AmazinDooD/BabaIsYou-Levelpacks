-- this file contains the overrides for blocks.lua as well, cuz its the main file I'll be editing
--                                                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- 															that was a lie, also that's in amazin_blocks.lua now

-- global variables
amaz_global = {
	FRAIL_TICKS = 5, -- Ticks taken to destroy an object because of FRAIL
	FRAIL_COUNTERS = {}, -- Counters for FRAIL
	TEXT_TYPES = { -- Text types so I dont have to remember magic numbers
		NOUN = 0, -- BABA, KEKE, ROCK etc
		VERB = 1, -- IS, PLAY, HAS etc
		PROPERTY = 2, -- PUSH, SHIFT, BOOM etc
		PREFIX = 3, -- IDLE, SELDOM, LONELY etc
		LETTER = 5, -- A, 4, BA etc
		INFIX = 7 -- ON, FACING, WITHOUT etc
	},
	PAUSE_MENU_REPLACEMENTS = {}, -- word_names but different ig
	FUNCS = {}, -- cool functions
	F = { -- constants for FLOAT-related properties
		ISNONE = 0,
		ISFLOAT = 1,
		ISREACH = 2,
		ISISOLATE = 3,
		ISSOAR = 4,
		ISBEACON = 5,
		ISPINNED = 6,
		ISASCEND = 7,
	},
	START_TIMER = 0, -- What the timer was at when the level was started.
	FLOAT_PROPS = { -- Table of FLOAT-related properties.
		"float",
		"reach",
		"isolate",
		"soar",
		"beacon",
		"ascend",
		"pinned"
	}
}
F = amaz_global.F
amaz_global.LTABLE = {
	[F.ISNONE] = 1,
	[F.ISFLOAT] = 2,
	[F.ISSOAR] = 3,
	[F.ISASCEND] = 4,
	[F.ISPINNED] = -2, -- Can't be -1 because it would short-circuit the over and under checks
	[F.ISISOLATE] = 0,
	[F.ISREACH] = 5,
	[F.ISBEACON] = 6
}

local objects = {
	"text_frail",
	"text_bouncy",
	"text_scribe",
	"text_poison",
	"text_except",
	"text_redcircle",
	"redcircle",
	"text_abide",
	"text_reach",
	"text_isolate",
	"text_soar",
	"text_beacon",
	"text_over",
	"text_under",
	"text_pinned",
	"text_ascend"
}
for  _,v in ipairs(objects) do
	table.insert(editor_objlist_order, v)
end

-- :egg:
particletypes["baba whirlwind"] = {
	object = "Level_customparticle",
	amount = 1000,
	colour = {0,3},
	add_to_list = true,
	init_extra = function()
		local unitid = MF_specialcreate("Level_customparticle")
		MF_loadsprite_special(unitid,0,0,"Data/Sprites/baba_0_1.png")
		MF_loadsprite_special(unitid,0,1,"Data/Sprites/baba_0_2.png")
		MF_loadsprite_special(unitid,0,2,"Data/Sprites/baba_0_3.png")
		MF_cleanspecialremove(unitid)
	end,
	update = function(timer)
		if amaz_global.START_TIMER == 0 then amaz_global.START_TIMER = timer end
		local adjtimer = (timer - amaz_global.START_TIMER) * 0.001
		for i,u in ipairs(backparticles) do
			u.values[XVEL] = u.values[XVEL] + (fixedrandom(0,1) == 1 and adjtimer or -adjtimer)
			u.values[YVEL] = u.values[YVEL] + (fixedrandom(0,1) == 1 and adjtimer or -adjtimer)
		end
	end
}

-- Logic here
editor_objlist["text_frail"] = {
    name = "text_frail",
    sprite_in_root = false,
    tiling = -1,
    type = amaz_global.TEXT_TYPES.PROPERTY,
    layer = 20,
    unittype = "text",
    tags = {"text_quality", "common"},
    colour = {1,1},
    colour_active = {1,2}
}

-- Logic here
editor_objlist["text_bouncy"] = {
	name = "text_bouncy",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.PROPERTY,
	layer = 20,
	unittype = "text",
	tags = {"text_quality", "common", "movement"},
	colour = {4,3},
	colour_active = {4,4}
}

-- Logic in amazin_convert.lua
editor_objlist["text_scribe"] = {
	name = "text_scribe",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.VERB,
	layer = 20,
	unittype = "text",
	tags = {"text_verb", "common"},
	colour = {3,0},
	colour_active = {3,1}
}

-- Logic here
editor_objlist["text_poison"] = {
	name = "text_poison",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.PROPERTY,
	layer = 20,
	unittype = "text",
	tags = {"text_quality", "common"},
	colour = {3,1},
	colour_active = {3,0}
}


-- Logic in amazin_conditions.lua
editor_objlist["text_except"] = {
	name = "text_except",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.INFIX,
	layer = 20,
	unittype = "text",
	tags = {"text_condition","common","text"},
	colour = {0,1},
	colour_active = {0,3}
}

-- Logic here
editor_objlist["text_abide"] = {
	name = "text_abide",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.VERB,
	layer = 20,
	unittype = "text",
	tags = {"text", "text_verb"},
	colour = {5,1},
	colour_active = {5,3}
}

-- Logic in amazin_tools.lua
editor_objlist["text_reach"] = {
	name = "text_reach",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.PROPERTY,
	layer = 20,
	unittype = "text",
	tags = {"text_quality", "common"},
	colour = {3,2},
	colour_active = {3,3}
}

-- Logic in amazin_tools.lua
editor_objlist["text_isolate"] = {
	name = "text_isolate",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.PROPERTY,
	layer = 20,
	unittype = "text",
	tags = {"text_quality", "common"},
	colour = {2,1},
	colour_active = {2,2}
}

-- Logic in amazin_tools.lua (also amaz_global.FUNCS.soar_check())
editor_objlist["text_soar"] = {
	name = "text_soar",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.PROPERTY,
	layer = 20,
	unittype = "text",
	tags = {"text_quality", "common"},
	colour = {1,3},
	colour_active = {1,4}
}

-- Logic in amazin_tools.lua (also amaz_global.FUNCS.soar_check())
editor_objlist["text_beacon"] = {
	name = "text_beacon",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.PROPERTY,
	layer = 20,
	unittype = "text",
	tags = {"text_quality", "common"},
	colour = {2,3},
	colour_active = {2,4}
}

-- Logic in amazin_conditions.lua
editor_objlist["text_over"] = {
	name = "text_over",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.INFIX,
	layer = 20,
	unittype = "text",
	tags = {"text", "text_condition", "common"},
	colour = {3,2},
	colour_active = {3,3}
}

-- Logic in amazin_conditions.lua
editor_objlist["text_under"] = {
	name = "text_under",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.INFIX,
	layer = 20,
	unittype = "text",
	tags = {"text", "text_condition", "common"},
	colour = {3,2},
	colour_active = {3,3}
}

editor_objlist["text_ascend"] = {
	name = "text_ascend",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.PROPERTY,
	layer = 20,
	unittype = "text",
	tags = {"text", "text_condition", "common"},
	colour = {5,3},
	colour_active = {5,4}
}

editor_objlist["text_pinned"] = {
	name = "text_pinned",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.PROPERTY,
	layer = 20,
	unittype = "text",
	tags = {"text", "text_condition", "common"},
	colour = {2,0},
	colour_active = {2,1}
}

-- Nouns
editor_objlist["text_redcircle"] = {
	name = "text_redcircle",
	sprite_in_root = false,
	tiling = -1,
	type = amaz_global.TEXT_TYPES.NOUN,
	layer = 20,
	unittype = "text",
	tags = {"text"},
	colour = {0,1},
	colour_active = {0,3},
	pairedwith = "redcircle"
}
editor_objlist["redcircle"] = {
	name = "redcircle",
	sprite_in_root = false,
	tiling = -1,
	layer = 20,
	type = "object",
	tags = {"abstract"},
	colour = {0,3},
	pairedwith = "text_redcircle"
}

formatobjlist()

-- Word Glossary support
if keys.IS_WORD_GLOSSARY_PRESENT then
	keys.WORD_GLOSSARY_FUNCS.register_author("AmazinDooD", {4,4})
	keys.WORD_GLOSSARY_FUNCS.add_entries_to_word_glossary{
		{
			base_obj = "text_frail",
			author = "AmazinDooD",
			description = [[Objects which are $1,2FRAIL$0,3 are destroyed
after ]]..amaz_global.FRAIL_TICKS..[[ turns.

Stacking $1,2FRAIL$0,3 does nothing.]]
		},
		{
			base_obj = "text_bouncy",
			author = "AmazinDooD",
			description = [[When an object comes in contact with a 
$4,4BOUNCY$0,3 object, it is bounced 
backward by 2 spaces.

Stacking $4,4BOUNCY$0,3 increases distance by
+1.]]
		},
		{
			base_obj = "text_abide",
			author = "AmazinDooD",
			description = [[Faces the same direction as the nearest
object after the $5,3ABIDE$0,3 rule.

If there are two objects equal distance 
away, choose a random one.]]
		},
		{
			base_obj = "text_reach",
			author = "AmazinDooD",
			description = [[Interacts both with objects that are $1,4FLOAT$0,3 and not $1,4FLOAT$0,3.]]
		},
		{
			base_obj = "text_isolate",
			author = "AmazinDooD",
			description = [[Exclusively interacts with objects that
are $3,3REACH$0,3.

Does not interact with objects that are
$2,2ISOLATE$0,3, unless they are also $3,3REACH$0,3.]]
		},
		{
			base_obj = "text_soar",
			author = "AmazinDooD",
			description = [[$1,4SOAR$0,3 objects cannot interact 
with non-$1,4SOAR$0,3 objects, including
collision.

This means that $1,4SOAR$0,3 objects will walk
through $5,1STOP$0,3-like objects that aren't
$1,4SOAR$0,3.]]
		},
		{
			base_obj = "text_beacon",
			author = "AmazinDooD",
			description = [[Will interact with both non-$1,4SOAR$0,3 objects and $1,4SOAR$0,3 objects.

Will not interact with $1,4FLOAT$0,3 objects,
unless the object is also $1,4FLOAT$0,3.]]
		},
		{
			base_obj = "text_over",
			author = "AmazinDooD",
			description = [[Activates if the second object is on a 
lower/higher float layer than the first.

In order from lowest to highest:
($2,1PINNED$0,3 and $2,2ISOLATE$0,3), NONE, $1,4FLOAT$0,3, $1,4SOAR$0,3, $5,4ASCEND$0,3.

$2,4BEACON$0,3 is considered under $1,4FLOAT$0,3 and equal
to NONE and $1,4SOAR$0,3.
$3,3REACH$0,3 is considered under $1,4SOAR$0,3 and equal 
to NONE and $1,4FLOAT$0,3.]],
			display_sprites = {"text_over","text_under"},
			display_name = "over/under"
		}
	}
end

amaz_global.FUNCS.distance = function(x1,x2,y1,y2)
	return math.sqrt((x1 - x2)^2 + (y1 - y2)^2)
end

amaz_global.FUNCS.min = function(t, key_to_num)
	key_to_num = key_to_num or true
	local min_key, min_val = -99, 99999
	for k,v in pairs(t) do
		if v < min_val then
			min_val = v
			min_key = key_to_num and k+0 or k
		end
	end
	return min_key, min_val
end

amaz_global.FUNCS.max = function(t, key_to_num)
	local max_key, max_val = -99, -99999
	key_to_num = key_to_num or true
	for k,v in pairs(t) do
		if v > max_val then
			max_val = v
			max_key = key_to_num and k+0 or k
		end
	end
	return max_key, max_val
end

amaz_global.FUNCS.find_distances = function(name,x,y)
	local targets = findall({name})
	local distances = {}
	for k,unitid in ipairs(targets) do
		local unit = mmf.newObject(unitid)
		distances[unit.fixed] = amaz_global.FUNCS.distance(x,unit.values[XPOS],y,unit.values[YPOS])
	end
	return distances
end

amaz_global.FUNCS.find_nearest = function(name,x,y)
	return amaz_global.FUNCS.min(amaz_global.FUNCS.find_distances(name,x,y))
end

amaz_global.FUNCS.find_farthest = function(name,x,y)
	return amaz_global.FUNCS.max(amaz_global.FUNCS.find_distances(name,x,y))
end

-- Similar to floating() but only checks for SOAR and BEACON
amaz_global.FUNCS.soar_check = function(id1,id2,x1_,y1_,x2_,y2_)
	local x1,y1 = x1_ or 0, y1_ or 0
	local x2,y2 = x2_ or x1, y2_ or y1
	local soar1, soar2 = -1,-1
	local unit1, unit2 = "empty", "empty"
	local ISNONE, ISSOAR, ISBEACON = amaz_global.F.ISNONE,1,2

	if id1 ~= 2 then
		unit1 = mmf.newObject(id1).strings[UNITNAME]
	end
	if id2 ~= 2 then
		unit2 = mmf.newObject(id2).strings[UNITNAME]
	end

	soar1 =
	hasfeature(unit1,"is","beacon",id1,x1,y1) ~= nil and ISBEACON or
	(hasfeature(unit1,"is","soar",id1,x1,y1) ~= nil and ISSOAR or ISNONE)

	soar2 =
	hasfeature(unit2,"is","beacon",id2,x2,y2) ~= nil and ISBEACON or
	(hasfeature(unit2,"is","soar",id2,x2,y2) ~= nil and ISSOAR or ISNONE)

	if (soar1 < ISBEACON) and (soar2 < ISBEACON) then -- SOAR logic
		return soar1 == soar2
	elseif (soar1 == ISBEACON) or (soar2 == ISBEACON) then -- BEACON logic
		return true
	end
	return false
end

amaz_global.FUNCS.contains = function(t,val)
	for _,v in pairs(t) do
		if v == val then return true end
	end
	return false
end

-- Returns a table of numbers stating which floating variants the object is.
amaz_global.FUNCS.get_floating_variants = function(id,x_,y_,single_)
	local x = x_ or 0
	local y = y_ or x
	local single = single_ or false
	local val, sval, name = {}, -1, "empty"
	local isnone = true

	if id ~= 2 and id ~= 1 then
		local unit = mmf.newObject(id)
		if unit then
			name = unit.strings[UNITNAME] or "empty"
		end
	end

	if hasfeature(name,"is","float",id,x,y) ~= nil then
		if single then sval = amaz_global.F.ISFLOAT
		else table.insert(val,amaz_global.F.ISFLOAT) end
		isnone = false
	end
	if hasfeature(name,"is","reach",id,x,y) ~= nil then
		if single then sval = amaz_global.F.ISREACH
		else table.insert(val,amaz_global.F.ISREACH) end
		isnone = false
	end
	if hasfeature(name,"is","isolate",id,x,y) ~= nil then
		if single then sval = amaz_global.F.ISISOLATE
		else table.insert(val,amaz_global.F.ISISOLATE) end
		isnone = false
	end
	if hasfeature(name,"is","soar",id,x,y) ~= nil then
		if single then sval = amaz_global.F.ISSOAR
		else table.insert(val,amaz_global.F.ISSOAR) end
		isnone = false
	end
	if hasfeature(name,"is","beacon",id,x,y) ~= nil then
		if single then sval = amaz_global.F.ISBEACON
		else table.insert(val,amaz_global.F.ISBEACON) end
		isnone = false
	end
	if hasfeature(name,"is","pinned",id,x,y) ~= nil then
		if single then sval = amaz_global.F.ISPINNED
		else table.insert(val,amaz_global.F.ISPINNED) end
		isnone = false
	end
	if hasfeature(name,"is","ascend",id,x,y) ~= nil then
		if single then sval = amaz_global.F.ISASCEND
		else table.insert(val,amaz_global.F.ISASCEND) end
		isnone = false
	end

	if isnone then
		if single then
			sval = amaz_global.F.ISNONE
		else
			val = {0}
		end
	end

	return single and sval or val
end

amaz_global.FUNCS.get_floating_variants_name = function(name,x_,y_,single_)
	local x = x_ or 0
	local y = y_ or x
	local single = single_ or false
	local val, sval = {}, -1
	local isnone = true

	if hasfeature(name,"is","float",nil,x,y) ~= nil then
		if single then sval = amaz_global.F.ISFLOAT
		else table.insert(val,amaz_global.F.ISFLOAT) end
		isnone = false
	end
	if hasfeature(name,"is","reach",nil,x,y) ~= nil then
		if single then sval = amaz_global.F.ISREACH
		else table.insert(val,amaz_global.F.ISREACH) end
		isnone = false
	end
	if hasfeature(name,"is","isolate",nil,x,y) ~= nil then
		if single then sval = amaz_global.F.ISISOLATE
		else table.insert(val,amaz_global.F.ISISOLATE) end
		isnone = false
	end
	if hasfeature(name,"is","soar",nil,x,y) ~= nil then
		if single then sval = amaz_global.F.ISSOAR
		else table.insert(val,amaz_global.F.ISSOAR) end
		isnone = false
	end
	if hasfeature(name,"is","beacon",nil,x,y) ~= nil then
		if single then sval = amaz_global.F.ISBEACON
		else table.insert(val,amaz_global.F.ISBEACON) end
		isnone = false
	end
	if hasfeature(name,"is","pinned",nil,x,y) ~= nil then
		if single then sval = amaz_global.F.ISPINNED
		else table.insert(val,amaz_global.F.ISPINNED) end
		isnone = false
	end
	if hasfeature(name,"is","ascend",nil,x,y) ~= nil then
		if single then sval = amaz_global.F.ISASCEND
		else table.insert(val,amaz_global.F.ISASCEND) end
		isnone = false
	end

	if isnone then
		if single then
			sval = amaz_global.F.ISNONE
		else
			val = {0}
		end
	end

	return single and sval or val
end

amaz_global.FUNCS.over_logic = function(float1,float2)
	local layertable = amaz_global.LTABLE
	local layer1,layer2 = layertable[float1] or -1, layertable[float2] or -1
	if (layer1 == -1) or (layer2 == -1) or (layer1 == layer2) then return false end

	if (layer1 == layertable[F.ISASCEND]) or (layer2 == layertable[F.ISPINNED]) then return true end
	if (layer1 == layertable[F.ISPINNED]) or (layer2 == layertable[F.ISASCEND]) then return false end

	if layer1 < layertable[F.ISREACH] and layer2 < layertable[F.ISREACH] then
		return layer1 > layer2
	else
		if layer1 == layertable[F.ISREACH] then -- REACH logic
			return layer2 == layertable[F.ISSOAR]
		elseif layer1 == layertable[F.ISBEACON] then -- BEACON logic
			return layer2 == layertable[F.ISFLOAT]
		end
	end
	return false
end

amaz_global.FUNCS.under_logic = function(float1,float2)
	local layertable = amaz_global.LTABLE
	local layer1,layer2 = layertable[float1] or -1, layertable[float2] or -1
	if (layer1 == -1) or (layer2 == -1) or (layer1 == layer2) then return false end

	if (layer1 == layertable[F.ISPINNED]) or (layer2 == layertable[F.ISASCEND]) then return true end
	if (layer1 == layertable[F.ISASCEND]) or (layer2 == layertable[F.ISPINNED]) then return false end

	if layer1 < layertable[F.ISREACH] and layer2 < layertable[F.ISREACH] then
		return layer1 < layer2
	else
		if layer1 == layertable[F.ISREACH] then -- REACH logic
			return layer2 ~= layertable[F.ISSOAR]
		elseif layer1 == layertable[F.ISBEACON] then -- BEACON logic
			return layer2 ~= layertable[F.ISFLOAT]
		end
	end
	return false
end

function amaz_global.FUNCS.debug_over_under()
	local nametable = {
		[F.ISNONE] = "none",
		[F.ISFLOAT] = "float",
		[F.ISREACH] = "reach",
		[F.ISISOLATE] = "isolate",
		[F.ISSOAR] = "soar",
		[F.ISBEACON] = "beacon",
		[F.ISPINNED] = "pinned",
		[F.ISASCEND] = "ascend"
	}
	print("--------------------------------------------------------")
	for k,v in pairs(F) do
		for kk,vv in pairs(F) do
			print("Called over_logic with params "..nametable[v]..", "..nametable[vv].." and recieved "..tostring(amaz_global.FUNCS.over_logic(v,vv)))
			print("Called under_logic with params "..nametable[v]..", "..nametable[vv].." and recieved "..tostring(amaz_global.FUNCS.under_logic(v,vv)))
		end
	end
	print("--------------------------------------------------------")
end

-- Pause menu replacements
amaz_global.PAUSE_MENU_REPLACEMENTS["redcircle"] = "$2,2clickbait youtube thumbnail red circle and arrow"

function stringify_table(t)
	local text = "{"
	local final, i = #t, 0
	for k,v in pairs(t) do
		local fv = v
		if (type(v) == "table") then fv = stringify_table(v) end
		if (type(v) == "string") then fv = "\""..fv.."\"" end
		if (type(k) == "string") then k = "\""..k.."\"" end
		text = text
		..tostring(k)
		.." = "
		..tostring(fv)
		..((i == final-1) and "" or ", ")
		i = i + 1
	end
	return text.."}"
end

function print_table(text_start_,t_,text_end_)
	local t = t_ or {}
	local text_start = text_start_ and tostring(text_start_) or ""
	local text_end = text_end_ and tostring(text_end_) or ""
	print(text_start..stringify_table(t)..text_end)
end

function print_table_simple(t_)
	local t = t_ or {}
	print(stringify_table(t))
end

table.insert(mod_hook_functions["undoed"], function()
	for k,v in pairs(amaz_global.FRAIL_COUNTERS) do
		if v > 0 and (mmf.newObject(MF_getfixed(k))) then -- mmf.newObject returns nil if the object doesn't exist, this way we only trigger the decrement if the object exists
			amaz_global.FRAIL_COUNTERS[k] = v - 1
			if v >= amaz_global.FRAIL_TICKS then amaz_global.FRAIL_COUNTERS[k] = v - 2 end -- decrement it by one more if it got destroyed this turn (trust)
			--print("Decremented frail counter of "..mmf.newObject(MF_getfixed(k)).strings[UNITNAME]..", it is now "..v-1)
		end
	end
end)

table.insert(mod_hook_functions["level_start"], function()
	--amaz_global.FUNCS.debug_over_under()
	amaz_global.START_TIMER = 0
	amaz_global.FRAIL_COUNTERS = {}
end)

-- Detect if an OVER/UNDER rule is about to cause an infinite loop and destroy the level if so
table.insert(mod_hook_functions["rule_update_after"], function(repeated)
	local done = false
	for k,rulelist in pairs(featureindex) do
		for i,rules in ipairs(rulelist) do
			local rule, conds = rules[1], rules[2] or {}
			--print_table("rule: ",rule)
			--print_table("conds: ",conds)
			local isoverunder = false
			for _,cond in ipairs(conds) do
				if (amaz_global.FUNCS.contains(cond,"over") or amaz_global.FUNCS.contains(cond,"under")) then
					if not (amaz_global.FUNCS.contains(cond, "never")) then
						isoverunder = true
					end
				end
			end
			for _,prop in ipairs(amaz_global.FLOAT_PROPS) do
				local disabled = hasfeature(rule[1],rule[2],"not "..rule[3]) ~= nil
				if rule[3] == prop and isoverunder then
					-- Disable the rule so it doesn't cause a lua error
					table.insert(featureindex[k][i][2],1,{"never",{}})
					if not disabled then
						HACK_INFINITY = 200
						destroylevel("infinity")
						done = true
						break
					end
				end
			end
			if done then break end
		end
		if done then break end
	end
end)