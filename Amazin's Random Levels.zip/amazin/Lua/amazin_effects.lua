local ef = effects
function effects(timer)
    ef(timer)
    -- add custom effects here
end