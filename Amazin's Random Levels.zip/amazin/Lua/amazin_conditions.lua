--[[
Things so i remember:
In "BABA NEAR ROCK AND KEKE IS YOU"
cdata.name = {"baba"}
params = {"rock","keke"}
]]

condlist["over"] = function(params,checkedconds,checkedconds_,cdata)
    local x,y,unitid,notcond = cdata.x, cdata.y, cdata.unitid, cdata.notcond
    local selffloat = amaz_global.FUNCS.get_floating_variants(unitid,x,y,true)
    local amtfound, alreadyfound = 0, {}

    if amaz_global.UNDO_PLZ then return false,checkedconds end

    -- Loop all objects after the OVER condition
    if #params > 0 then
        for k,v in ipairs(params) do
            local pname = v
            local pnot = false
            if (string.sub(v, 1, 4) == "not ") then
                pnot = true
                pname = string.sub(v, 5)
            end

            -- Group is janky.
            if (string.sub(pname, 1, 5) == "group") then
                return false,checkedconds
            end

            if (v ~= "empty") and (v ~= "level") then
                if not pnot then
                    -- X over Y is Z
                    if alreadyfound[k] == nil then
                        local vfloat = amaz_global.FUNCS.get_floating_variants_name(v,nil,nil,true)

                        --[[
                        Layer logic
                        PINNED = ISOLATE < NONE < FLOAT < SOAR
                        NONE = FLOAT < REACH < SOAR
                        NONE = BEACON = SOAR < FLOAT 
                        ]]
                        --print("(Line 101) Calling over_logic() with "..tostring(selffloat)..", "..tostring(vfloat))
                        if amaz_global.FUNCS.over_logic(selffloat,vfloat) then
                            alreadyfound[k] = 1
                            amtfound = amtfound + 1
                        end
                    end
                else
                    -- X over not Y is Z
                    local found = false
                    for curname, curunits in pairs(unitlists) do
                        if (curname ~= pname) and (#curunits > 0) and (curname ~= "text") and (string.sub(curname, 1, 5) ~= "text_") then
                            for _,curuid in ipairs(curunits) do
                                if (curuid ~= unitid) and (alreadyfound[curuid] == nil) then
                                    local curunit = mmf.newObject(curuid)
                                    local curlayer = amaz_global.FUNCS.get_floating_variants(curuid,curunit.values[XPOS],curunit.values[YPOS],true)
                                    --print("(Line 116) Calling over_logic() with "..tostring(selffloat)..", "..tostring(curlayer))
                                    if (amaz_global.FUNCS.over_logic(selffloat,curlayer)) then
                                        alreadyfound[k] = 1
                                        found = true
                                        break
                                    end
                                end
                            end
                        end
                        if found then break end
                    end
                    if found then
                        alreadyfound[k] = 1
                        amtfound = amtfound + 1
                    end
                end
            elseif v == "empty" then
                local emptyfloat = amaz_global.FUNCS.get_floating_variants_name("empty",nil,nil,true)
                --print("(Line 134) Calling over_logic() with "..tostring(selffloat)..", "..tostring(emptyfloat))
                if (amaz_global.FUNCS.over_logic(selffloat,emptyfloat)) then
                    alreadyfound[k] = 1
                    amtfound = amtfound + 1
                end
            elseif v == "level" then
                -- The level is always treated as non-floating
                --print("(Line 141) Calling over_logic() with "..tostring(selffloat)..", 0")
                if amaz_global.FUNCS.over_logic(selffloat,F.ISNONE) then
                    alreadyfound[k] = 1
                    amtfound = amtfound + 1
                end
            end
        end
    else
        print("OVER called with no paramaters :(")
        return false,checkedconds
    end

    local satisfied = amtfound == #params
    if notcond then satisfied = not satisfied end
    return satisfied,checkedconds
end

condlist["under"] = function(params, checkedconds, checkedconds_, cdata)
    local x,y,unitid,notcond = cdata.x, cdata.y, cdata.unitid, cdata.notcond
    local selffloat = amaz_global.FUNCS.get_floating_variants(unitid,x,y,true)
    local amtfound, alreadyfound = 0, {}

    if amaz_global.UNDO_PLZ then return false,checkedconds end

    -- Loop all objects after the UNDER condition
    if #params > 0 then
        for k,v in ipairs(params) do
            local pname = v
            local pnot = false
            if (string.sub(v, 1, 4) == "not ") then
                pnot = true
                pname = string.sub(v, 5)
            end

            -- Group is janky.
            if (string.sub(pname, 1, 5) == "group") then
                return false,checkedconds
            end

            if (v ~= "empty") and (v ~= "level") then
                if not pnot then
                    -- X under Y is Z
                    if alreadyfound[k] == nil then
                        local vfloat = amaz_global.FUNCS.get_floating_variants_name(v,nil,nil,true)

                        --[[
                        Layer logic
                        PINNED = ISOLATE < NONE < FLOAT < SOAR
                        NONE = FLOAT < REACH < SOAR
                        NONE = BEACON = SOAR < FLOAT 
                        ]]
                        --print("(Line 101) Calling over_logic() with "..tostring(selffloat)..", "..tostring(vfloat))
                        if amaz_global.FUNCS.under_logic(selffloat,vfloat) then
                            alreadyfound[k] = 1
                            amtfound = amtfound + 1
                        end
                    end
                else
                    -- X under not Y is Z
                    local found = false
                    for curname, curunits in pairs(unitlists) do
                        if (curname ~= pname) and (#curunits > 0) and (curname ~= "text") and (string.sub(curname, 1, 5) ~= "text_") then
                            for _,curuid in ipairs(curunits) do
                                if (curuid ~= unitid) and (alreadyfound[curuid] == nil) then
                                    local curunit = mmf.newObject(curuid)
                                    local curlayer = amaz_global.FUNCS.get_floating_variants(curuid,curunit.values[XPOS],curunit.values[YPOS],true)
                                    --print("(Line 116) Calling over_logic() with "..tostring(selffloat)..", "..tostring(curlayer))
                                    if (amaz_global.FUNCS.under_logic(selffloat,curlayer)) then
                                        alreadyfound[k] = 1
                                        found = true
                                        break
                                    end
                                end
                            end
                        end
                        if found then break end
                    end
                    if found then
                        alreadyfound[k] = 1
                        amtfound = amtfound + 1
                    end
                end
            elseif v == "empty" then
                local emptyfloat = amaz_global.FUNCS.get_floating_variants_name("empty",nil,nil,true)
                --print("(Line 134) Calling over_logic() with "..tostring(selffloat)..", "..tostring(emptyfloat))
                if (amaz_global.FUNCS.under_logic(selffloat,emptyfloat)) then
                    alreadyfound[k] = 1
                    amtfound = amtfound + 1
                end
            elseif v == "level" then
                -- The level is always treated as non-floating
                --print("(Line 141) Calling over_logic() with "..tostring(selffloat)..", 0")
                if amaz_global.FUNCS.under_logic(selffloat,F.ISNONE) then
                    alreadyfound[k] = 1
                    amtfound = amtfound + 1
                end
            end
        end
    else
        print("UNDER called with no paramaters :(")
        return false,checkedconds
    end

    local satisfied = amtfound == #params
    if notcond then satisfied = not satisfied end
    return satisfied,checkedconds
end