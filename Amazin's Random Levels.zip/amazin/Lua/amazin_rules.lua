function invertconds(conds,db,target_)
	local newconds = db or {}
	local crash = false
	local doparentheses = true
	local neverfound = false
	
	if (#conds > 0) then
		for a,cond in ipairs(conds) do
			local newcond = {}
			local condname = cond[1]
			local condname_s = ""
			local params = cond[2]
			
			local prefix = string.sub(condname, 1, 4)
			
			if (prefix == "(not") then
				condname_s = string.sub(condname, 6)
				condname = string.sub(condname, 6)
			elseif (prefix == "not ") then
				condname_s = string.sub(condname, 5)
				condname = string.sub(condname, 5)
			else
				condname_s = condname
				condname = "not " .. condname
			end
			
			newcond[1] = condname
			newcond[2] = {}
			local valid = true
			
			if (#params > 0) then
				for m,n in ipairs(params) do
                    -- EDIT: add EXCEPT
					if (condname_s ~= "feeling") and (condname_s ~= "except") then
						table.insert(newcond[2], n)
					else
						--MF_alert(n .. ", " .. tostring(target_) .. ", " .. cond[1] .. ", " .. condname .. ", " .. condname_s)
						if (target_ == nil) or (target_ ~= "not " .. n) then
							table.insert(newcond[2], n)
						elseif (cond[1] == "feeling") or (cond[1] == "except") then
							crash = true
						end
					end
				end
			end
			
			if (#params > 0) and (#newcond[2] == 0) then
				valid = false
			end
			
			if valid then
				table.insert(newconds, newcond)
			end
		end
	else
		table.insert(newconds, {"never",{}})
		doparentheses = false
		neverfound = true
	end
	
	if doparentheses then
		for i,cond in ipairs(newconds) do
			if (i == 1) then
				cond[1] = "(" .. cond[1]
			end
			
			if (i == #newconds) then
				cond[1] = cond[1] .. ")"
			end
		end
	end
	
	return newconds,crash,neverfound
end