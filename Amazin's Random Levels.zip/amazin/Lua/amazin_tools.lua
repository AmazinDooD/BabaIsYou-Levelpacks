-- This also adds coloured rules if you have it because yea
function writerules(parent,name,x_,y_)
	local basex = x_
	local basey = y_
	local linelimit = 12
	local maxcolumns = 4

	local x,y = basex,basey

	if (#visualfeatures > 0) then
		writetext(langtext("rules_colon"),0,x,y,name,true,2,true)
	end

	local i_ = 1

	local count = 0
	local allrules = {}

	local custom = MF_read("level","general","customruleword")

	-- Used a bit further down
	local level = generaldata.strings[CURRLEVEL]

	for i,rules in ipairs(visualfeatures) do
		local text = ""
		local rule = rules[1]

		if (#custom == 0) then
			text = text .. colourstring(rule[1]) .. " "
		else
			text = text .. colourstring(rule[1],nil,custom) .. " "
		end

		local conds = rules[2]
		local ids = rules[3]
		local tags = rules[4]

		local fullinvis = true
		for a,b in ipairs(ids) do
			for c,d in ipairs(b) do
				local dunit = mmf.newObject(d)

				if dunit.visible then
					fullinvis = false
				end
			end
		end

		if (fullinvis == false) then
			if (#conds > 0) then
				for a,cond in ipairs(conds) do
					local middlecond = true

					if (cond[2] == nil) or ((cond[2] ~= nil) and (#cond[2] == 0)) then
						middlecond = false
					end

					if middlecond then
						if (#custom == 0) then
							local target = cond[1]
							local isnot = string.sub(target, 1, 4)
							local target_ = target

							if (isnot == "not ") then
								target_ = string.sub(target, 5)
							else
								isnot = ""
							end

							if (word_names[target_] ~= nil) then
								target = isnot .. word_names[target_]
							end

							text = text .. colourstring(cond[1],target) .. " "
						else
							text = text .. colourstring(cond[1],nil,custom) .. " "
						end

						if (cond[2] ~= nil) then
							if (#cond[2] > 0) then
								for c,d in ipairs(cond[2]) do
									if (#custom == 0) then
										local target = d
										local isnot = string.sub(target, 1, 4)
										local target_ = target

										if (isnot == "not ") then
											target_ = string.sub(target, 5)
										else
											isnot = ""
										end

										if (word_names[target_] ~= nil) then
											target = isnot .. word_names[target_]
										end

										text = text .. colourstring(d,target) .. " "
									else
										text = text .. colourstring(d,nil,custom) .. " "
									end

									if (#cond[2] > 1) and (c ~= #cond[2]) then
										text = text .. colourstring("and","& ")
									end
								end
							end
						end

						if (a < #conds) then
							text = text .. colourstring("and","& ")
						end
					else
						if (#custom == 0) then
							text = colourstring(cond[1]) .. " " .. text
						else
							text = colourstring(cond[1],nil,custom) .. " " .. text
						end
					end
				end
			end

			local target = rule[3]
			local isnot = string.sub(target, 1, 4)
			local target_ = target

			if (isnot == "not ") then
				target_ = string.sub(target, 5)
			else
				isnot = ""
			end

			if (word_names[target_] ~= nil) then
				target = isnot .. word_names[target_]
			end

			if (#custom == 0) then
				text = text .. colourstring(rule[2]) .. " " .. colourstring(rule[3],target)
			else
				text = text .. colourstring(rule[2],nil,custom) .. " " .. colourstring(rule[3],nil,custom)
			end

			for a,b in ipairs(tags) do
				if (b == "mimic") then
					text = text .. colourstring("mimic",nil," (mimic)")
				end
			end

            -- EDIT: replace things here
            for k, v in pairs(amaz_global.PAUSE_MENU_REPLACEMENTS) do
                text = text:gsub(k, v)
            end

			-- level-specific replacements
			if level == "16level" then
				text = text
				:gsub("b","k")
				:gsub("a","e")
				:gsub("n","b")
			end

			if (allrules[text] == nil) then
				allrules[text] = 1
				count = count + 1
			else
				allrules[text] = allrules[text] + 1
			end
			i_ = i_ + 1
		end
	end

	-- Yes i hardcoded removing some rules because i couldnt be bothered fixing it
	-- What are you going to do about it
	if level == "48level" then
		allrules["$1,4wind$0,3 on $2,2keke$0,3 $5,3follow$0,3 $2,2keke$0,3"] = nil
		allrules["$1,4wind$0,3 make $1,4bubble$0,3"] = nil
		allrules["$0,3wind$0,3 on $0,3keke$0,3 $0,3follow$0,3 $0,3keke$0,3"] = nil
		allrules["$0,3wind$0,3 make $0,3bubble$0,3"] = nil
	end

	local columns = math.min(maxcolumns, math.floor((count - 1) / linelimit) + 1)
	local columnwidth = math.min(screenw - f_tilesize * 2, columns * f_tilesize * 10) / columns

	i_ = 1

	local maxlimit = 4 * linelimit

	for i,v in pairs(allrules) do
		if v ~= nil then
			local text = i

			if (i_ <= maxlimit) then
				local currcolumn = math.floor((i_ - 1) / linelimit) - (columns * 0.5)
				x = basex + columnwidth * currcolumn + columnwidth * 0.5
				y = basey + (((i_ - 1) % linelimit) + 1) * f_tilesize * 0.8
			end

			if (i_ <= maxlimit-1) then
				if (v == 1) then
					writetext(text,0,x,y,name,true,2,true)
				elseif (v > 1) then
					writetext(tostring(v) .. " x " .. text,0,x,y,name,true,2,true)
				end
			end

			i_ = i_ + 1
		end
	end

	if (i_ > maxlimit-1) then
		writetext("(+ " .. tostring(i_ - maxlimit) .. ")",0,x,y,name,true,2,true)
	end
end

function colourstring(text_,display_,custom)
  local text = text_ or ""
  local display = display_ or text
  local result = ""
  if string.sub(text,1,4) == "not " and custom == nil then
    local n1,n2 = getpalcolour("text_not","active")
    if n1 ~= 0 or n2 ~= 3 then
      result = "$"..n1..","..n2.."not "
    else
      result = "not "
    end
    text = string.sub(text,5)
    display = string.sub(display,5)
  end
  local c1,c2 = getpalcolour("text_"..text,"active",true)
  while string.sub(text,1,5) == "text_" and custom == nil and c1 == nil do
    local n1,n2 = getpalcolour("text_text_","active")
    if n1 ~= 0 or n2 ~= 3 or result ~= nil then
      result = result.."$"..n1..","..n2.."text_"
    else
      result = "text_"
    end
    text = string.sub(text,6)
    display = string.sub(display,6)
    c1,c2 = getpalcolour("text_"..text,"active",true)
  end
  if c1 == nil then
    c1,c2 = 0,3
  end
  local insert = custom or display
  if (c1 ~= 0 or c2 ~= 3) then
    result = result .. "$"..c1..","..c2..insert.."$0,3"
  elseif result ~= "" then
    result = result .. "$0,3" .. insert
  else
    result = insert
  end
  return result
end

getpalcolour = getpalcolour or function(a,b,c) return 0,3 end

-- Edit: implement ISOLATE, REACH, SOAR, BEACON
function floating(id1,id2,x1_,y1_,x2_,y2_)
	local x1 = x1_ or 0
	local y1 = y1_ or 0
	local x2 = x2_ or x1
	local y2 = y2_ or y1
	local float1, float2 = amaz_global.FUNCS.get_floating_variants(id1,x1,y1,true), amaz_global.FUNCS.get_floating_variants(id2,x2,y2,true)

	--print("1st object: "..float1..", 2nd object: "..float2)
	-- F is defined in amazin_main.lua btw

	if (float1 == F.ISASCEND) or (float1 == F.ISPINNED) then
		float1 = F.ISNONE
	end
	if (float2 == F.ISASCEND) or (float2 == F.ISPINNED) then
		float2 = F.ISNONE
	end

	if (float1 < F.ISREACH) and (float2 < F.ISREACH) then -- Normal FLOAT logic
		return (float1 == float2)
	elseif (float1 == F.ISREACH and float2 == F.ISISOLATE) or (float2 == F.ISREACH and float1 == F.ISISOLATE) then -- If one is REACH and one is ISOLATE
		return true
	elseif ((float1 == F.ISREACH) or (float2 == F.ISREACH)) and (float1 ~= amaz_global.F.ISSOAR and float2 ~= F.ISSOAR) then -- If either are REACH and none are SOAR
		return true
	elseif (float1 == F.ISSOAR) and (float2 == F.ISSOAR) then -- If both are SOAR
		return true
	elseif ((float1 == F.ISBEACON) or (float2 == F.ISBEACON)) then -- If either are BEACON
		return true
	end
	return false
end